# Rank Gaussian Normalization

This python implementation is built on a fork of https://github.com/michaeljahrer/rankGauss/blob/master/rankGaussMain.cpp, thanks Michael Jahrer shared this. Python source code: https://github.com/RogerZhangsc/Porto-Seguros-Safe-Driver-Prediction/blob/master/Rank_Gaussian_Normalization.py
